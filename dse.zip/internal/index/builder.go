package index

import (
	"distributed-search-engine/internal/document"
	"encoding/json"
	"io"
	"log"
	"os"
	"time"

	"github.com/blevesearch/bleve/v2"
)

func IndexDocument(index bleve.Index, inputFile string) {
	jsonlFile, err := os.Open(inputFile)
	if err != nil {
		log.Printf("Open jsonl file: %v", err)
	}
	defer jsonlFile.Close()
	decoder := json.NewDecoder(jsonlFile)
	start := time.Now()
	docsIndexed := 0

	for {
		var doc document.Document

		if err := decoder.Decode(&doc); err != nil {
			log.Printf("Decode Error, skipping it.. - %v", err)
			if err == io.EOF {
				break
			}
			continue
		}
		if err := index.Index(doc.ID, doc); err != nil {
			log.Printf("failed to index document %s: %v", doc.ID, err)
			continue
		}
		docsIndexed++
		if docsIndexed%5000 == 0 {
			log.Printf("Read %d pages from XML...", docsIndexed)
		}
	}
	elapsed := time.Since(start)
	log.Printf(
		"[indexer] indexing completed: documents_indexed=%d elapsed=%s",
		docsIndexed,
		elapsed,
	)
}
